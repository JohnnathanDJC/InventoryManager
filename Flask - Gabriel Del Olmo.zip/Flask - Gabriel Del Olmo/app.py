from flask import Flask, jsonify, request
import mariadb
import sys
#imporst db access config
from config import DATABASE_CONFIG

app = Flask(__name__)

try:
        conn = mariadb.connect(**DATABASE_CONFIG)
except mariadb.Error as e:
        print(f"Error  on connection: {e}")
        sys.exit(1)

cursor = conn.cursor()


#En esta direccion saldra mi nombre
@app.route('/mis_datos', methods=['GET'])
def mis_datos():
        return jsonify({'datos': 'Gabriel Del Olmo'})

#En esta direccion se obtendra la informacion para llenar la tabla de records
@app.route('/get_items', methods=['GET'])
def get_items():
    cursor.execute("SELECT * FROM Product") 
    items = cursor.fetchall()
    list = []
    for item in items: 
        list.append({
              "UPC":item[0], 
              "name_Product":item[1],
              "price_Product":item[2],
              "quantity_Product":item[3]
        })
    
    # Convertir los resultados en un formato más amigable o devolverlos directamente
    response = jsonify({"data":list})
    response.headers.add("Content-type",'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

#En esta direccion se obtendra la informacion para llenar la tabla de items
@app.route('/get_product_detail', methods=['GET'])
def get_detail():
    cursor.execute("SELECT * FROM Detail_Product")  
    details = cursor.fetchall()
    list = []
    for detail in details:
        list.append({
              "UPC":detail[0],
              "category_Product":detail[1],
              "brand":detail[2],
              "batch":detail[4]
        })
    
    # Convertir los resultados en un formato más amigable o devolverlos directamente
    response = jsonify({"data":list})
    response.headers.add("Content-type",'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

#En esta direccion se obtendra la informacion para llenar la tabla de providers
@app.route('/get_providers', methods=['GET'])
def get_providers():
    cursor.execute("SELECT * FROM Provider") 
    providers = cursor.fetchall()
    list = []
    for provider in providers:
        list.append({
              "id_Provider":provider[0],
              "name_Provider":provider[1],
              "contact":provider[2]
        })
    # Convertir los resultados en un formato más amigable o devolverlos directamente
    response = jsonify({"data":list})
    response.headers.add("Content-type",'application/json')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

#Insertar un nuevo item en el DB
@app.route('/insert_item', methods=['POST'])
def new_item():
        datos = request.json
        item_UPC = datos.get('UPC') 
        item_name = datos.get('name_Product')
        item_price = datos.get('price_Product')
        item_quantity = datos.get('quantity_Product')

        strQry = 'insert into Product'
        strQry += "(UPC, , name_Product, price_Product, quantity_Product)"
        strQry += f"values ('{item_UPC}','{item_name}','{item_price}','{item_quantity}' )"

        cursor.execute(strQry)
        conn.commit()
        response = {"message": "Record inserted"}
        return jsonify(response) , 200

#Modificar un item 
@app.route('/update_item', methods=['POST'])
def update_item():
        datos = request.json
        item_UPC = datos.get('UPC')
        item_name = datos.get('name_Product')
        item_price = datos.get('price_Product')
        item_quantity = datos.get('quantity_Product')
        
        strQry = 'update Product '
        strQry += f"set name_Product = '{item_name}', "
        strQry += f"price_Product = '{item_price}', "
        strQry += f"quantity_Product = '{item_quantity}', "
        strQry += f"where item_UPC = {UPC} "

        cursor.execute(strQry)
        conn.commit()

        response = {"message": "Record updated"}
        return jsonify(response), 200

#Eliminar Item
@app.route('/delete_item/<string:UPC>', methods=['DELETE'])
def del_item(UPC):
        strQry = 'DELETE FROM Product WHERE UPC = ?'  #eliminar donde item donde el upc sea..
        cursor.execute(strQry, (UPC,))
        conn.commit()
        return jsonify({"message": "Item deleted successfully"}), 200

if __name__ == '__main__':
        app.run(host='0.0.0.0', port=5000)