DATABASE_CONFIG = {
	'host': 'linux-vm2.arecibo.inter.edu',
	'port': 3306,
	'user': 'tiendamanager',
	'password': 'tiendasecreta',
	'database': 'InventoryDB'
}
